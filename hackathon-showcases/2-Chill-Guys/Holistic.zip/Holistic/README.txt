Hello!
This is Nichita Mitrea, from 2 Chill Guys and this is the submission.
Hope everything works, and for any issues contact me at andsad52@gmail.com

Preliminaries:
    Its preferable to work in a separate environment as this can conflict with dependencies, and also with a cuda-enabled GPU for track2.
    To set the environment up do the following:
        
        cd dictionary_learning
        pip install -r requirements.txt
        To download (pip):
            - torch
            - tqdm
            - transformers
            - holisticai[all]
            - nnsight
            - wandb
        Of course this assumes that standard ML libraries like scikit-learn are isntalled.

Each notebook represents the respective traks submission.
Track1 - Using optuna to develop custom pipelines for any dataset in the holisticai library.
Track2 - Using DistillBert to investigate the mechanistic interpetability of stereotypes through SAEs.
As these are .ipynb files, they have example output.
Lastly, there are comments sprinkled around in both notebooks.

Yet again, thank you for this opportunity.

Kind regards,
Nichita Mitrea, One Chill Guy