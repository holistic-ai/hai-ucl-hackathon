# debugging flag for use in other scripts
DEBUG = False